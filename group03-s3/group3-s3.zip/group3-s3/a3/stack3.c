#include <stdio.h>

int main(void){
    for(int i=0; i<17; i++){
        printf("\x0a\x0d\x0a\x0d");
    }
}